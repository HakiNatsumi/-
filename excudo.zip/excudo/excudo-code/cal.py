"""cal.py - Máy tính đơn giản thực hiện các phép tính cơ bản.

Các phép toán hỗ trợ: cộng (+), trừ (-), nhân (*), chia (/).
Chia cho 0 sẽ được xử lý ngoại lệ.
"""


def cong(a, b):
    """Trả về tổng của a và b."""
    return a + b


def tru(a, b):
    """Trả về hiệu của a và b."""
    return a - b


def nhan(a, b):
    """Trả về tích của a và b."""
    return a * b


def chia(a, b):
    """Trả về thương của a và b. Ném lỗi nếu chia cho 0."""
    if b == 0:
        raise ZeroDivisionError("Không thể chia cho 0!")
    return a / b


def tinh_toan(so1, phep_tuan, so2):
    """Thực hiện phép tính dựa trên ký hiệu: +, -, *, /."""
    phep_tuan = phep_tuan.strip().lower()
    if phep_tuan == "+":
        return cong(so1, so2)
    if phep_tuan == "-":
        return tru(so1, so2)
    if phep_tuan == "*":
        return nhan(so1, so2)
    if phep_tuan == "/":
        return chia(so1, so2)
    raise ValueError(f"Phép toán không hợp lệ: {phep_tuan!r}")


def main():
    """Vòng lặp nhập liệu và tính toán cơ bản."""
    print("=== Máy tính cơ bản (nhập 'q' để thoát) ===")
    while True:
        print(f"\nCác phép toán: + (cộng), - (trừ), * (nhân), / (chia)")
        lua_chon = input("Nhập 'q' để thoát hoặc Enter để tính tiếp: ").strip().lower()
        if lua_chon == "q":
            print("Tạm biệt!")
            break

        try:
            so1 = float(input("Nhập số thứ nhất: "))
            phep_tuan = input("Nhập phép toán (+, -, *, /): ")
            so2 = float(input("Nhập số thứ hai: "))
            ket_qua = tinh_toan(so1, phep_tuan, so2)
            print(f"Kết quả: {so1} {phep_tuan} {so2} = {ket_qua}")
        except ValueError as e:
            print(f"Giá trị nhập vào không hợp lệ: {e}")
        except ZeroDivisionError as e:
            print(f"Lỗi: {e}")


if __name__ == "__main__":
    main()