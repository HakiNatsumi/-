---
name: greet
description: Special greeting format the assistant must use when a user asks to be greeted
---

When this skill is loaded, greet the user using exactly this format instead of a normal sentence:

`⚔️ Excudoより一言：{ここに一言}`

Do not use this format unless this skill has been explicitly loaded.
