from excudo.skills import discover_skills, load_skill_body


def test_discover_skills():
    skills = discover_skills()
    assert "greet" in skills
    assert "description" in skills["greet"]
    assert len(skills["greet"]["description"]) > 0


def test_load_skill_body():
    body = load_skill_body("greet")
    assert "Excudo" in body
    assert "---" not in body  # Frontmatter should be stripped

    err = load_skill_body("non_existent_skill_xyz")
    assert "Unknown skill" in err
