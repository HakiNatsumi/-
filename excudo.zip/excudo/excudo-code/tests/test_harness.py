from types import SimpleNamespace
from excudo.harness import Harness
from excudo.permissions import PermissionGate
from excudo import config


class MockChunkDelta:
    def __init__(self, content=None, reasoning=None, tool_calls=None):
        self.content = content
        self.reasoning = reasoning
        self.tool_calls = tool_calls
        self.model_extra = {"reasoning": reasoning} if reasoning else {}


def make_chunk(content=None, reasoning=None, tool_calls=None):
    delta = MockChunkDelta(content=content, reasoning=reasoning, tool_calls=tool_calls)
    return SimpleNamespace(choices=[SimpleNamespace(delta=delta)])


class MockModel:
    def __init__(self, chunk_sequences):
        self._sequences = list(chunk_sequences)

    def stream(self, messages, tools):
        if self._sequences:
            return iter(self._sequences.pop(0))
        return iter([])


def test_harness_initialization_and_reset():
    model = MockModel([])
    gate = PermissionGate(auto_approve=True)
    harness = Harness(model, "System prompt", permission_gate=gate)

    assert len(harness.history) == 1
    assert harness.history[0]["role"] == "system"

    # Simulate added messages
    harness._history.append({"role": "user", "content": "hi"})
    assert len(harness.history) == 2

    harness.reset()
    assert len(harness.history) == 1
    assert harness.history[0]["content"] == "System prompt"


def test_harness_compact_history():
    model = MockModel([])
    gate = PermissionGate(auto_approve=True)
    harness = Harness(model, "System prompt", permission_gate=gate)

    # Fill history beyond MAX_HISTORY_MESSAGES
    original_max = config.MAX_HISTORY_MESSAGES
    config.MAX_HISTORY_MESSAGES = 6
    try:
        for i in range(10):
            harness._history.append({"role": "user", "content": f"msg {i}"})

        harness.compact_history()
        assert len(harness.history) <= 6
        assert harness.history[0]["role"] == "system"
        assert "[System note:" in harness.history[1]["content"]
    finally:
        config.MAX_HISTORY_MESSAGES = original_max


def test_harness_run_text_and_reasoning():
    chunks = [
        make_chunk(reasoning="Thinking through the code..."),
        make_chunk(content="Hello "),
        make_chunk(content="world!"),
    ]
    model = MockModel([chunks])
    gate = PermissionGate(auto_approve=True)
    harness = Harness(model, "System prompt", permission_gate=gate)

    events = list(harness.run("Hi"))

    types = [e["type"] for e in events]
    assert "reasoning_delta" in types
    assert "answer_delta" in types

    answer = "".join(e["text"] for e in events if e["type"] == "answer_delta")
    assert answer == "Hello world!"
    assert harness.history[-1]["content"] == "Hello world!"
