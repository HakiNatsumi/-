from pathlib import Path
from excudo.permissions import (
    PermissionGate,
    ActionRisk,
    is_within_workspace,
)


def test_is_within_workspace(tmp_path: Path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    inside = workspace / "src" / "main.py"
    outside = tmp_path / "other" / "secret.txt"

    assert is_within_workspace(str(inside), workspace_root=workspace) is True
    assert is_within_workspace(str(outside), workspace_root=workspace) is False


def test_permission_gate_auto_approve(tmp_path: Path):
    gate = PermissionGate(workspace_root=tmp_path, auto_approve=True)
    res = gate.check("run_command", {"command": "rm -rf /"})
    assert res.allowed is True


def test_permission_gate_defaults(tmp_path: Path):
    gate = PermissionGate(workspace_root=tmp_path, auto_approve=False)

    # Read inside workspace is safe
    safe_path = tmp_path / "file.txt"
    res_read = gate.check("read_file", {"path": str(safe_path)})
    assert res_read.allowed is True
    assert res_read.risk == ActionRisk.SAFE

    # Read outside workspace requires approval
    outside_path = tmp_path.parent / "file.txt"
    res_outside = gate.check("read_file", {"path": str(outside_path)})
    assert res_outside.allowed is False
    assert res_outside.risk == ActionRisk.OUTSIDE_WORKSPACE

    # Write requires approval
    res_write = gate.check("write_file", {"path": str(safe_path), "content": "hi"})
    assert res_write.allowed is False
    assert res_write.risk == ActionRisk.MODIFY

    # Delete requires approval
    res_delete = gate.check("delete_file", {"path": str(safe_path)})
    assert res_delete.allowed is False
    assert res_delete.risk == ActionRisk.MODIFY

    # Run command requires approval
    res_cmd = gate.check("run_command", {"command": "dir"})
    assert res_cmd.allowed is False
    assert res_cmd.risk == ActionRisk.EXECUTE


def test_permission_gate_callback(tmp_path: Path):
    decisions = []

    def mock_callback(name: str, args: dict, risk: ActionRisk) -> bool:
        decisions.append(name)
        return name == "write_file"  # Approve write, deny others

    gate = PermissionGate(
        workspace_root=tmp_path,
        auto_approve=False,
        approval_callback=mock_callback,
    )

    res_write = gate.check("write_file", {"path": str(tmp_path / "a.txt"), "content": "x"})
    assert res_write.allowed is True

    res_cmd = gate.check("run_command", {"command": "echo hi"})
    assert res_cmd.allowed is False
    assert decisions == ["write_file", "run_command"]
