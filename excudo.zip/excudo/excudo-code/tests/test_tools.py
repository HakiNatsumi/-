import tempfile
from pathlib import Path
from excudo.tools import (
    read_file,
    write_file,
    edit_file,
    delete_file,
    list_dir,
    run_command,
    grep_search,
)


def test_write_and_read_file(tmp_path: Path):
    target = tmp_path / "subdir" / "sample.txt"
    res_write = write_file(str(target), "line 1\nline 2\nline 3\n")
    assert "Successfully wrote" in res_write
    assert target.exists()

    # Read all
    content = read_file(str(target))
    assert content == "line 1\nline 2\nline 3\n"

    # Read with offset and limit
    partial = read_file(str(target), offset=2, limit=1)
    assert partial == "line 2\n"

    # Read non-existent
    err = read_file(str(tmp_path / "not_found.txt"))
    assert "Error:" in err


def test_edit_file(tmp_path: Path):
    target = tmp_path / "code.py"
    target.write_text("def hello():\n    return 'world'\n", encoding="utf-8")

    # Successful replacement
    res = edit_file(str(target), "return 'world'", "return 'excudo'")
    assert "Successfully updated" in res
    assert target.read_text(encoding="utf-8") == "def hello():\n    return 'excudo'\n"

    # Target not found
    err_not_found = edit_file(str(target), "missing_text", "new")
    assert "Target text not found" in err_not_found

    # Target ambiguous (multiple occurrences)
    target.write_text("repeat\nrepeat\n", encoding="utf-8")
    err_ambiguous = edit_file(str(target), "repeat", "once")
    assert "appears 2 times" in err_ambiguous


def test_delete_file(tmp_path: Path):
    target = tmp_path / "delete-me.txt"
    target.write_text("content", encoding="utf-8")

    result = delete_file(str(target))
    assert "Successfully deleted" in result
    assert not target.exists()

    missing = delete_file(str(target))
    assert "does not exist" in missing

    directory = tmp_path / "folder"
    directory.mkdir()
    directory_result = delete_file(str(directory))
    assert "only files can be deleted" in directory_result
    assert directory.exists()


def test_list_dir(tmp_path: Path):
    (tmp_path / "file1.txt").write_text("hello", encoding="utf-8")
    sub = tmp_path / "subfolder"
    sub.mkdir()
    (sub / "file2.txt").write_text("world", encoding="utf-8")

    output = list_dir(str(tmp_path), max_depth=2)
    assert "[FILE] file1.txt" in output
    assert "[DIR]  subfolder/" in output
    assert "[FILE] file2.txt" in output


def test_run_command():
    res = run_command("python --version")
    assert "Exit code: 0" in res
    assert "Python" in res

    res_timeout = run_command("python -c \"import time; time.sleep(5)\"", timeout=1)
    assert "timed out" in res_timeout.lower()


def test_grep_search(tmp_path: Path):
    f1 = tmp_path / "file_a.txt"
    f1.write_text("antigravity AI assistant\nsuper agent\n", encoding="utf-8")
    f2 = tmp_path / "file_b.txt"
    f2.write_text("regular text\n", encoding="utf-8")

    # String search
    res = grep_search("AI assistant", str(tmp_path))
    assert "file_a.txt:1: antigravity AI assistant" in res
    assert "file_b.txt" not in res

    # Regex search
    res_re = grep_search(r"super\s+\w+", str(tmp_path), is_regex=True)
    assert "super agent" in res_re
