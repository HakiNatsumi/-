import sys
from pathlib import Path

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from excudo import config
from excudo.harness import Harness
from excudo.model import Model
from excudo.permissions import ActionRisk, PermissionGate
from excudo.skills import discover_skills

CHANNEL_STYLE = {
    "reasoning": {"streaming_title": "Reasoning", "final_title": "Reasoning", "style": "dim"},
    "answer": {"streaming_title": "Excudo", "final_title": "Excudo", "style": "cyan"},
}


class StreamPanel:
    """Renders streamed text token-by-token, then sets it into a bordered panel once complete."""

    def __init__(self, console: Console):
        self._console = console
        self._live: Live | None = None
        self._channel: str | None = None
        self._text = ""

    def feed(self, channel: str, text: str) -> None:
        if channel != self._channel:
            self.close()
            self._channel = channel
            self._text = ""
            self._live = Live(console=self._console, refresh_per_second=20, transient=True)
            self._live.start()
        self._text += text
        info = CHANNEL_STYLE.get(channel, {"streaming_title": channel, "style": "white"})
        style = info["style"]
        self._live.update(
            Text(f"{info['streaming_title']}\n", style=f"bold {style}")
            + Text(self._text, style=style)
        )

    def close(self) -> None:
        if self._live:
            self._live.stop()
            if self._text.strip():
                info = CHANNEL_STYLE.get(
                    self._channel, {"final_title": self._channel or "Output", "style": "white"}
                )
                self._console.print(
                    Panel(
                        self._text.strip(),
                        title=info["final_title"],
                        border_style=info["style"],
                    )
                )
        self._live = None
        self._channel = None


def make_permission_callback(console: Console, gate: PermissionGate):
    def ask_permission(name: str, args: dict, risk: ActionRisk) -> bool:
        if gate.auto_approve:
            return True

        if risk == ActionRisk.EXECUTE:
            cmd = args.get("command", "")
            console.print(f"\n[bold yellow]⚠️ Shell command execution requested:[/] [bold cyan]{cmd}[/]")
        elif risk == ActionRisk.OUTSIDE_WORKSPACE:
            path = args.get("path", "")
            console.print(
                f"\n[bold red]⚠️ Operation outside workspace:[/] [bold yellow]{name}(path='{path}')[/]"
            )
        elif risk == ActionRisk.MODIFY:
            path = args.get("path", "")
            action = "File deletion requested" if name == "delete_file" else "File modification requested"
            console.print(f"\n[bold yellow]📝 {action}:[/] [bold cyan]{path}[/]")
        else:
            console.print(f"\n[bold yellow]🔧 Tool execution requested:[/] [bold cyan]{name}({args})[/]")

        try:
            choice = console.input("[bold green]Allow this action? [y/N]: [/]").strip().lower()
            return choice in {"y", "yes"}
        except (EOFError, KeyboardInterrupt):
            console.print("\n[red]Action denied.[/]")
            return False

    return ask_permission


def print_help(console: Console) -> None:
    table = Table(title="Excudo Commands", border_style="cyan")
    table.add_column("Command", style="bold green")
    table.add_column("Description", style="white")

    table.add_row("/help", "Show this help")
    table.add_row("/clear, /reset", "Clear conversation history and start a new session")
    table.add_row("/skills", "List available skills")
    table.add_row("/status, /config", "Show LLM connection, model, and configuration status")
    table.add_row("/auto [on|off]", "Enable or disable automatic tool approval")
    table.add_row("exit, quit", "Exit the application")
    console.print(table)


def print_status(console: Console, harness: Harness, gate: PermissionGate) -> None:
    table = Table(title="Excudo Configuration Status", border_style="magenta")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="white")

    table.add_row("Model", config.MODEL_NAME)
    table.add_row("Base URL", config.BASE_URL)
    table.add_row("Workspace", str(config.WORKSPACE_ROOT))
    table.add_row("Auto Approve", "ON (automatic)" if gate.auto_approve else "OFF (confirmation required)")
    table.add_row("Max Turns / Request", str(config.MAX_TURNS))
    table.add_row("Conversation History", f"{len(harness.history)} messages")
    console.print(table)


def print_skills(console: Console) -> None:
    skills = discover_skills()
    table = Table(title="Available Skills", border_style="yellow")
    table.add_column("Skill", style="bold green")
    table.add_column("Description", style="white")

    if not skills:
        table.add_row("(None)", "No skills found in the skills/ directory")
    else:
        for name, meta in skills.items():
            table.add_row(name, meta.get("description", ""))
    console.print(table)


def main() -> None:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stdin.reconfigure(encoding="utf-8")

    console = Console(legacy_windows=False)
    gate = PermissionGate()
    gate.approval_callback = make_permission_callback(console, gate)

    harness = Harness(Model(), config.DEFAULT_SYSTEM_PROMPT, permission_gate=gate)

    # Initialize prompt_toolkit session with persistent history
    history_file = Path.home() / ".excudo_history"
    session = PromptSession(history=FileHistory(str(history_file)))

    console.print(
        Panel(
            "[bold cyan]Excudo[/] — Local Coding Agent\n"
            f"[dim]Model: {config.MODEL_NAME} | Endpoint: {config.BASE_URL}[/]\n"
            "Type [bold green]/help[/] to see available commands or [bold red]exit[/] to quit.",
            border_style="cyan",
        )
    )

    while True:
        try:
            user_input = session.prompt("excudo > ").strip()
        except KeyboardInterrupt:
            # Ctrl+C clears line without quitting
            console.print()
            continue
        except EOFError:
            # Ctrl+D quits
            break

        if not user_input:
            continue

        lower_input = user_input.lower()
        if lower_input in {"exit", "quit"}:
            break

        # Handle slash commands
        if user_input.startswith("/"):
            cmd_parts = user_input.split()
            cmd = cmd_parts[0].lower()

            if cmd in {"/help", "/?"}:
                print_help(console)
                continue
            elif cmd in {"/clear", "/reset"}:
                harness.reset()
                console.print("[green]✓ Conversation history cleared. Starting a new session.[/]")
                continue
            elif cmd == "/skills":
                print_skills(console)
                continue
            elif cmd in {"/status", "/config"}:
                print_status(console, harness, gate)
                continue
            elif cmd == "/auto":
                if len(cmd_parts) > 1:
                    gate.auto_approve = cmd_parts[1].lower() in {"on", "1", "true", "yes"}
                else:
                    gate.auto_approve = not gate.auto_approve
                state_str = "[bold green]ON[/]" if gate.auto_approve else "[bold yellow]OFF[/]"
                console.print(f"Auto-approve is now: {state_str}")
                continue
            else:
                console.print(f"[red]Unknown command: {cmd}. Type /help to see available commands.[/]")
                continue

        # Run agent loop
        stream_panel = StreamPanel(console)
        try:
            for event in harness.run(user_input):
                if event["type"] == "reasoning_delta":
                    stream_panel.feed("reasoning", event["text"])
                elif event["type"] == "answer_delta":
                    stream_panel.feed("answer", event["text"])
                elif event["type"] == "tool_call":
                    stream_panel.close()
                    console.print(
                        Panel(
                            f"Arguments: {event['args']}\nResult: {event['result']}",
                            title=f"🔧 Tool: {event['name']}",
                            border_style="yellow",
                        )
                    )
                elif event["type"] == "error":
                    stream_panel.close()
                    console.print(Panel(event["content"], title="⚠️ Error", border_style="red"))
        except KeyboardInterrupt:
            stream_panel.close()
            console.print("\n[yellow]⚠️ The current response was interrupted (Ctrl+C).[/]")
        finally:
            stream_panel.close()


if __name__ == "__main__":
    main()
