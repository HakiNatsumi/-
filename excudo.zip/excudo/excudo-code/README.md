# Excudo

Local AI coding agent built on a Qwen3 model served locally via vLLM. Uses a
**Model/Harness** architecture: the Model only handles LLM token streaming and reasoning;
the Harness owns conversation state, tool execution, context compaction, and sandboxing permissions.

## Quick Start

```bash
uv sync
uv run main.py
```

Run test suite:
```bash
uv run pytest -v
```

Requires network access to the local LLM endpoint configured in `excudo/config.py` or `.env`.

## Features

- **Model/Harness Separation**: Model handles API communication; Harness controls side effects.
- **Dual-channel Streaming**: Token-by-token live streaming for both reasoning thoughts (`reasoning`) and answers (`answer`).
- **Core Coding Tools**:
  - `read_file`: Read file contents with line offset and limit support.
  - `write_file`: Create or overwrite files, automatically creating parent directories.
  - `edit_file`: Safe, surgical exact search-and-replace for minimal code changes.
  - `delete_file`: Delete a file (directories cannot be deleted with this tool).
  - `list_dir`: Recursively explore workspace tree (ignores `.git`, `.venv`, `__pycache__`).
  - `run_command`: Execute shell commands with timeout and output capture.
  - `grep_search`: Fast pattern and regex search across workspace files.
  - `load_skill`: Dynamic on-demand skill loading.
- **Permission Gate & Sandboxing**:
  - Distinguishes safe read-only operations from modifying (`write_file`, `edit_file`, `delete_file`) and execution (`run_command`) actions.
  - Path sandboxing: Flags or rejects operations attempting to access files outside the workspace root.
  - Interactive approval prompts `[y/N]` before modifying files or executing shell commands.
  - Toggleable auto-approve mode via `/auto` or `EXCUDO_AUTO_APPROVE=1`.
- **Enhanced CLI**:
  - Powered by `prompt-toolkit` with persistent command history (arrow up/down).
  - Slash commands: `/help`, `/clear`, `/skills`, `/status`, `/auto`.
  - Non-destructive interrupt: Ctrl+C halts ongoing streaming without exiting the session.
- **Context Management**:
  - Automatic history compaction when conversation exceeds `MAX_HISTORY_MESSAGES`.
  - Output truncation for oversized tool returns to prevent context window explosion.

## Layout

- `excudo/model.py` — thin LLM client wrapper (handles streaming and vLLM reasoning extraction)
- `excudo/harness.py` — agent loop: streams model chunks, executes tools, compacts context history
- `excudo/permissions.py` — permission gate, action risk classification, and workspace sandboxing
- `excudo/tools.py` — pluggable tool registry
- `excudo/skills.py` — discovers and loads `skills/<name>/SKILL.md` files
- `excudo/config.py` — environment variable configuration and `.env` loader
- `main.py` — interactive CLI entry point with Rich and prompt-toolkit
- `skills/` — drop-in skill definitions
- `tests/` — automated unit and integration tests (pytest)

## Configuration (.env)

Create a `.env` file in the root directory to customize settings:

```env
EXCUDO_BASE_URL=http://192.168.0.7:8000/v1
EXCUDO_MODEL_NAME=unsloth/Qwen3.8-27B-NVFP4
EXCUDO_MAX_TURNS=15
EXCUDO_AUTO_APPROVE=0
EXCUDO_MAX_HISTORY_MESSAGES=40
```
