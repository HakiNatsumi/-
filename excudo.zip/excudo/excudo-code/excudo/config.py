import os
from pathlib import Path


def load_env(env_path: Path | None = None) -> None:
    """Loads key=value pairs from a .env file into os.environ if not already set."""
    if env_path is None:
        env_path = Path.cwd() / ".env"
    if not env_path.is_file():
        return
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            key = key.strip()
            val = val.strip().strip("'\"")
            if key not in os.environ:
                os.environ[key] = val
    except OSError:
        pass


load_env()

WORKSPACE_ROOT = Path(os.getenv("EXCUDO_WORKSPACE_ROOT", str(Path.cwd().resolve())))
BASE_URL = os.getenv("EXCUDO_BASE_URL", "http://192.168.0.7:8000/v1")
API_KEY = os.getenv("EXCUDO_API_KEY", "not-needed")
MODEL_NAME = os.getenv("EXCUDO_MODEL_NAME", "unsloth/Qwen3.8-27B-NVFP4")
MAX_TURNS = int(os.getenv("EXCUDO_MAX_TURNS", "15"))
AUTO_APPROVE = os.getenv("EXCUDO_AUTO_APPROVE", "0").lower() in {"1", "true", "yes"}
MAX_HISTORY_MESSAGES = int(os.getenv("EXCUDO_MAX_HISTORY_MESSAGES", "40"))

DEFAULT_SYSTEM_PROMPT = f"""You are Excudo, an expert AI software engineer and local coding assistant.
You help the user inspect, write, debug, and execute code directly in their workspace.

### Environment & Context:
- Operating System: Windows
- Workspace Root: {WORKSPACE_ROOT}

### Guidelines:
1. Always inspect files or list directories with tools before making assumptions.
2. For reading files, use `read_file`.
3. For modifying code:
   - Prefer `edit_file` for targeted changes to preserve existing code structure.
   - Use `write_file` when creating new files or when rewriting is explicitly required.
   - Use `delete_file` to delete a file only when the user requests it.
4. For searching, use `grep_search` to find symbols, functions, or patterns.
5. For executing tests, building, or git commands, use `run_command`.
6. Explain your reasoning and changes clearly and concisely.
7. Respond in English by default. If the user explicitly requests another language, use that language.
"""
