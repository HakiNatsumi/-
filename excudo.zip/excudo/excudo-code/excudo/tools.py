import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .skills import discover_skills, load_skill_body

IGNORED_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
    ".idea",
    ".vscode",
}


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    handler: Callable[..., str]

    def schema(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


def read_file(path: str, offset: int = 1, limit: int | None = None) -> str:
    """Read the contents of a file at the given path."""
    target_path = Path(path)
    if not target_path.exists():
        return f"Error: File '{path}' does not exist."
    if target_path.is_dir():
        return f"Error: '{path}' is a directory, not a file. Use list_dir instead."
    try:
        content = target_path.read_text(encoding="utf-8", errors="replace")
        lines = content.splitlines(keepends=True)
        total_lines = len(lines)
        if offset < 1:
            offset = 1
        start_idx = offset - 1
        if start_idx >= total_lines:
            return f"File '{path}' has {total_lines} lines. Requested offset {offset} is out of bounds."

        selected_lines = lines[start_idx:]
        if limit is not None and limit > 0:
            selected_lines = selected_lines[:limit]

        result = "".join(selected_lines)
        # Cap at 50KB to protect LLM context window
        if len(result) > 50_000:
            result = (
                result[:50_000]
                + f"\n... [Output truncated at 50KB. Total lines in file: {total_lines}]"
            )
        return result
    except OSError as e:
        return f"Error reading {path}: {e}"


def write_file(path: str, content: str) -> str:
    """Write or overwrite a file with given content, creating parent directories if needed."""
    try:
        target_path = Path(path)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text(content, encoding="utf-8")
        line_count = len(content.splitlines())
        return f"Successfully wrote {line_count} lines ({len(content.encode('utf-8'))} bytes) to '{path}'."
    except OSError as e:
        return f"Error writing to {path}: {e}"


def edit_file(path: str, target: str, replacement: str) -> str:
    """Perform an exact search-and-replace on a unique target code block in a file."""
    target_path = Path(path)
    if not target_path.exists():
        return f"Error: File '{path}' does not exist."
    if target_path.is_dir():
        return f"Error: '{path}' is a directory, not a file."
    try:
        content = target_path.read_text(encoding="utf-8", errors="replace")
        count = content.count(target)
        if count == 0:
            return (
                f"Error: Target text not found in '{path}'. "
                "Ensure target matches the file content exactly, including whitespace and line breaks."
            )
        if count > 1:
            return (
                f"Error: Target text appears {count} times in '{path}'. "
                "Please provide more surrounding lines in 'target' to ensure uniqueness."
            )
        new_content = content.replace(target, replacement, 1)
        target_path.write_text(new_content, encoding="utf-8")
        return f"Successfully updated '{path}'."
    except OSError as e:
        return f"Error editing {path}: {e}"


def delete_file(path: str) -> str:
    """Delete a file without removing directories."""
    target_path = Path(path)
    if not target_path.exists() and not target_path.is_symlink():
        return f"Error: File '{path}' does not exist."
    if target_path.is_dir() and not target_path.is_symlink():
        return f"Error: '{path}' is a directory; only files can be deleted."
    try:
        target_path.unlink()
        return f"Successfully deleted '{path}'."
    except OSError as e:
        return f"Error deleting {path}: {e}"


def list_dir(path: str = ".", max_depth: int = 2) -> str:
    """List files and subdirectories up to a specified depth, ignoring build/cache directories."""
    root_path = Path(path)
    if not root_path.exists():
        return f"Error: Directory '{path}' does not exist."
    if not root_path.is_dir():
        return f"Error: '{path}' is a file, not a directory. Use read_file instead."

    lines: list[str] = [f"Directory: {root_path.resolve()}"]
    item_count = 0
    max_items = 150

    def _traverse(current: Path, depth: int, prefix: str = "") -> None:
        nonlocal item_count
        if depth > max_depth or item_count >= max_items:
            return

        try:
            entries = sorted(
                current.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())
            )
        except OSError as e:
            lines.append(f"{prefix}[Access Error: {e}]")
            return

        for entry in entries:
            if item_count >= max_items:
                lines.append(f"{prefix}... [Truncated after {max_items} items]")
                return

            if entry.name in IGNORED_DIRS:
                continue

            item_count += 1
            if entry.is_dir():
                lines.append(f"{prefix}[DIR]  {entry.name}/")
                _traverse(entry, depth + 1, prefix + "  ")
            else:
                try:
                    size = entry.stat().st_size
                except OSError:
                    size = 0
                lines.append(f"{prefix}[FILE] {entry.name} ({size} B)")

    _traverse(root_path, depth=1)
    return "\n".join(lines)


def run_command(command: str, timeout: int = 60) -> str:
    """Execute a shell command with a timeout, capturing stdout and stderr."""
    try:
        normalized_command = command.strip()
        match = re.match(r"^(python(?:3)?|py)(\s+.*)?$", normalized_command, flags=re.IGNORECASE)
        if match:
            suffix = match.group(2) or ""
            normalized_command = f'"{sys.executable}"{suffix}'

        proc = subprocess.run(
            normalized_command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=Path.cwd(),
            encoding="utf-8",
            errors="replace",
        )
        stdout = proc.stdout.strip()
        stderr = proc.stderr.strip()
        output_parts = [f"Exit code: {proc.returncode}"]
        if stdout:
            if len(stdout) > 10_000:
                stdout = (
                    stdout[:5000]
                    + f"\n... [Output truncated {len(stdout) - 10000} chars] ...\n"
                    + stdout[-5000:]
                )
            output_parts.append(f"STDOUT:\n{stdout}")
        if stderr:
            if len(stderr) > 10_000:
                stderr = (
                    stderr[:5000]
                    + f"\n... [Stderr truncated {len(stderr) - 10000} chars] ...\n"
                    + stderr[-5000:]
                )
            output_parts.append(f"STDERR:\n{stderr}")
        if not stdout and not stderr:
            output_parts.append("(Command produced no output)")
        return "\n\n".join(output_parts)
    except subprocess.TimeoutExpired:
        return f"Error: Command timed out after {timeout} seconds."
    except Exception as e:
        return f"Error executing command: {e}"


def grep_search(query: str, path: str = ".", is_regex: bool = False) -> str:
    """Search for a string or regex pattern across files, returning matching lines."""
    root = Path(path)
    if not root.exists():
        return f"Error: Path '{path}' does not exist."

    flags = re.IGNORECASE
    try:
        pattern = re.compile(query if is_regex else re.escape(query), flags)
    except re.error as e:
        return f"Invalid regex pattern '{query}': {e}"

    matches: list[str] = []
    max_matches = 50
    target_files = [root] if root.is_file() else root.rglob("*")

    for file_path in target_files:
        if len(matches) >= max_matches:
            break
        if not file_path.is_file():
            continue
        if any(part in IGNORED_DIRS for part in file_path.parts):
            continue

        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
            for line_idx, line in enumerate(content.splitlines(), start=1):
                if pattern.search(line):
                    try:
                        rel_path = file_path.relative_to(Path.cwd())
                    except ValueError:
                        rel_path = file_path
                    matches.append(f"{rel_path}:{line_idx}: {line.strip()}")
                    if len(matches) >= max_matches:
                        break
        except (OSError, UnicodeDecodeError):
            continue

    if not matches:
        return f"No matches found for '{query}' in '{path}'."

    result = "\n".join(matches)
    if len(matches) >= max_matches:
        result += f"\n... (Reached limit of {max_matches} matches)"
    return result


def _build_load_skill_tool() -> Tool:
    skills = discover_skills()
    listing = "\n".join(
        f"- {name}: {meta['description']}" for name, meta in skills.items()
    )
    description = (
        "Load the full instructions for a named skill.\nAvailable skills:\n"
        + (listing or "(none found)")
    )
    return Tool(
        name="load_skill",
        description=description,
        parameters={
            "type": "object",
            "properties": {"name": {"type": "string", "description": "Skill name"}},
            "required": ["name"],
        },
        handler=load_skill_body,
    )


REGISTRY: dict[str, Tool] = {
    "read_file": Tool(
        name="read_file",
        description="Read the contents of a file at the given path. Optionally specify offset line and line limit.",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "The path to the file to read."},
                "offset": {
                    "type": "integer",
                    "description": "Optional starting line number (1-indexed). Defaults to 1.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Optional maximum number of lines to read.",
                },
            },
            "required": ["path"],
        },
        handler=read_file,
    ),
    "write_file": Tool(
        name="write_file",
        description="Write or overwrite a file with given content. Automatically creates parent directories if needed.",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to the file to write."},
                "content": {
                    "type": "string",
                    "description": "The complete content to write into the file.",
                },
            },
            "required": ["path", "content"],
        },
        handler=write_file,
    ),
    "edit_file": Tool(
        name="edit_file",
        description="Perform an exact search-and-replace on a single target block of code within a file.",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to the file to edit."},
                "target": {
                    "type": "string",
                    "description": "The exact existing text to replace. Must match uniquely.",
                },
                "replacement": {
                    "type": "string",
                    "description": "The new replacement text.",
                },
            },
            "required": ["path", "target", "replacement"],
        },
        handler=edit_file,
    ),
    "delete_file": Tool(
        name="delete_file",
        description="Delete a file. Directories cannot be deleted with this tool.",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to the file to delete."},
            },
            "required": ["path"],
        },
        handler=delete_file,
    ),
    "list_dir": Tool(
        name="list_dir",
        description="List files and directories in a given path up to a specified depth.",
        parameters={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory path to list. Defaults to '.' (current workspace).",
                },
                "max_depth": {
                    "type": "integer",
                    "description": "Maximum directory recursion depth. Defaults to 2.",
                },
            },
        },
        handler=list_dir,
    ),
    "run_command": Tool(
        name="run_command",
        description="Execute a shell/terminal command and return stdout, stderr, and exit code. Use for running tests, build scripts, linters, git, etc.",
        parameters={
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Command execution timeout in seconds. Defaults to 60.",
                },
            },
            "required": ["command"],
        },
        handler=run_command,
    ),
    "grep_search": Tool(
        name="grep_search",
        description="Search for a text pattern or regular expression across files in a directory.",
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search string or regex pattern.",
                },
                "path": {
                    "type": "string",
                    "description": "The directory or file path to search in. Defaults to '.'",
                },
                "is_regex": {
                    "type": "boolean",
                    "description": "Whether to treat query as a regular expression. Defaults to false.",
                },
            },
            "required": ["query"],
        },
        handler=grep_search,
    ),
    "load_skill": _build_load_skill_tool(),
}
