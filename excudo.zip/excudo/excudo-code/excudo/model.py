from collections.abc import Iterator

from openai import OpenAI

from . import config


def extra_field(obj, name: str):
    """Reads a field the openai SDK's pydantic models don't officially declare
    (e.g. vLLM's `reasoning`), whether it landed as an attribute or in
    model_extra."""
    value = getattr(obj, name, None)
    if value is not None:
        return value
    extra = getattr(obj, "model_extra", None)
    return extra.get(name) if extra else None


class Model:
    """Thin wrapper around the LLM API.

    Knows how to ask the model for a completion given messages and tool
    schemas. Knows nothing about what the tools do, the filesystem, or the
    shell — that is the Harness's job.
    """

    def __init__(
        self,
        base_url: str = config.BASE_URL,
        api_key: str = config.API_KEY,
        model: str = config.MODEL_NAME,
    ):
        self._client = OpenAI(base_url=base_url, api_key=api_key)
        self._model = model

    def complete(self, messages: list[dict], tools: list[dict]):
        response = self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
        )
        return response.choices[0].message

    def stream(self, messages: list[dict], tools: list[dict]) -> Iterator:
        """Yields raw chunk deltas as the model generates them, for live
        token-by-token rendering."""
        return self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            stream=True,
        )
