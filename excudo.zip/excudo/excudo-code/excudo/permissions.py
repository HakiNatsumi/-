from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Callable

from . import config


class ActionRisk(Enum):
    SAFE = "safe"  # Read-only operations within workspace
    MODIFY = "modify"  # File creation or edits
    EXECUTE = "execute"  # Command execution
    OUTSIDE_WORKSPACE = "outside_workspace"  # Access outside workspace root


# Classification of registered tools
TOOL_RISK_MAP: dict[str, ActionRisk] = {
    "read_file": ActionRisk.SAFE,
    "list_dir": ActionRisk.SAFE,
    "grep_search": ActionRisk.SAFE,
    "load_skill": ActionRisk.SAFE,
    "write_file": ActionRisk.MODIFY,
    "edit_file": ActionRisk.MODIFY,
    "delete_file": ActionRisk.MODIFY,
    "run_command": ActionRisk.EXECUTE,
}


def is_within_workspace(path_str: str, workspace_root: Path | None = None) -> bool:
    """Check if the given path resolves to inside workspace root."""
    if workspace_root is None:
        workspace_root = config.WORKSPACE_ROOT
    try:
        target = Path(path_str).resolve()
        return target.is_relative_to(workspace_root.resolve())
    except (ValueError, OSError):
        return False


@dataclass
class PermissionResult:
    allowed: bool
    reason: str
    risk: ActionRisk


# Signature for interactive user approval callback: (tool_name, args, risk) -> bool
ApprovalCallback = Callable[[str, dict, ActionRisk], bool]


class PermissionGate:
    """Controls tool execution security, sandboxing, and interactive approvals."""

    def __init__(
        self,
        workspace_root: Path | None = None,
        auto_approve: bool | None = None,
        approval_callback: ApprovalCallback | None = None,
    ):
        self.workspace_root = workspace_root or config.WORKSPACE_ROOT
        self.auto_approve = (
            config.AUTO_APPROVE if auto_approve is None else auto_approve
        )
        self.approval_callback = approval_callback

    def check(self, tool_name: str, args: dict) -> PermissionResult:
        """Evaluates whether a tool call is permitted."""
        if self.auto_approve:
            return PermissionResult(
                allowed=True,
                reason="Auto-approve is enabled.",
                risk=ActionRisk.SAFE,
            )

        base_risk = TOOL_RISK_MAP.get(tool_name, ActionRisk.EXECUTE)

        # Check path sandboxing for tools taking a path
        if "path" in args:
            path_val = args["path"]
            if not is_within_workspace(path_val, self.workspace_root):
                base_risk = ActionRisk.OUTSIDE_WORKSPACE

        # Safe actions within workspace are auto-allowed
        if base_risk == ActionRisk.SAFE:
            return PermissionResult(
                allowed=True,
                reason="Safe read-only operation inside workspace.",
                risk=base_risk,
            )

        # Interactive approval callback
        if self.approval_callback:
            allowed = self.approval_callback(tool_name, args, base_risk)
            reason = (
                "Approved by user."
                if allowed
                else "Denied by user (Permission rejected)."
            )
            return PermissionResult(allowed=allowed, reason=reason, risk=base_risk)

        # Without callback and not auto-approved, default deny modifying/executing actions
        return PermissionResult(
            allowed=False,
            reason=f"Action '{tool_name}' requires explicit user approval ({base_risk.value}).",
            risk=base_risk,
        )
