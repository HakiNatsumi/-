from pathlib import Path

import yaml

SKILLS_DIR = Path(__file__).resolve().parent.parent / "skills"


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---"):
        return {}, text
    _, frontmatter, body = text.split("---", 2)
    return yaml.safe_load(frontmatter) or {}, body.strip()


def discover_skills() -> dict[str, dict]:
    """Scans skills/<name>/SKILL.md for frontmatter only (name + description).

    Deliberately does not read the body here: this keeps the load_skill tool
    schema small (and prefix-cache friendly) even as more skills get added.
    The full body is only read when a skill is actually invoked.
    """
    skills: dict[str, dict] = {}
    if not SKILLS_DIR.exists():
        return skills
    for skill_file in sorted(SKILLS_DIR.glob("*/SKILL.md")):
        meta, _ = _parse_frontmatter(skill_file.read_text(encoding="utf-8"))
        name = meta.get("name", skill_file.parent.name)
        skills[name] = {"description": meta.get("description", ""), "path": skill_file}
    return skills


def load_skill_body(name: str) -> str:
    entry = discover_skills().get(name)
    if not entry:
        return f"Unknown skill: {name}"
    _, body = _parse_frontmatter(entry["path"].read_text(encoding="utf-8"))
    return body
