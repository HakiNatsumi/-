import json
from collections.abc import Iterator

from . import config
from .model import Model, extra_field
from .permissions import PermissionGate
from .tools import REGISTRY


class Harness:
    """Owns conversation state and tool execution.

    The Model only ever sees messages and tool schemas; it never touches a
    file or a process directly. All side effects happen here, guarded by the
    PermissionGate.
    """

    def __init__(
        self,
        model: Model,
        system_prompt: str,
        permission_gate: PermissionGate | None = None,
    ):
        self._model = model
        self._system_prompt = system_prompt
        self._history: list[dict] = [{"role": "system", "content": system_prompt}]
        self._tool_schemas = [tool.schema() for tool in REGISTRY.values()]
        self._permission_gate = permission_gate or PermissionGate()

    @property
    def history(self) -> list[dict]:
        return list(self._history)

    def reset(self) -> None:
        """Resets conversation history to initial system prompt."""
        self._history = [{"role": "system", "content": self._system_prompt}]

    def compact_history(self) -> None:
        """Prunes older messages when history exceeds the configured threshold."""
        if len(self._history) <= config.MAX_HISTORY_MESSAGES:
            return

        system_msg = self._history[0]
        keep_count = max(4, config.MAX_HISTORY_MESSAGES - 2)
        recent_msgs = self._history[-keep_count:]

        # Avoid orphaned role="tool" messages at the beginning of the slice
        while recent_msgs and recent_msgs[0].get("role") == "tool":
            recent_msgs.pop(0)

        pruned_count = len(self._history) - len(recent_msgs) - 1
        note = {
            "role": "system",
            "content": f"[System note: {pruned_count} earlier messages were pruned to maintain context window.]",
        }
        self._history = [system_msg, note] + recent_msgs

    def run(self, user_input: str) -> Iterator[dict]:
        """Runs the agent loop for one user turn.

        Yields events as they happen so the CLI can render live:
          - {"type": "reasoning_delta"/"answer_delta", "text": str}: streamed fragments.
          - {"type": "tool_call", "name", "args", "result"}: fully executed tool calls.
          - {"type": "error", "content"}: loop safety cap or connection errors.
        """
        self.compact_history()
        self._history.append({"role": "user", "content": user_input})

        for _ in range(config.MAX_TURNS):
            content_parts: list[str] = []
            tool_calls_acc: dict[int, dict] = {}
            reasoning_started = False
            content_started = False

            try:
                stream_iter = self._model.stream(self._history, self._tool_schemas)
                for chunk in stream_iter:
                    delta = chunk.choices[0].delta

                    reasoning_piece = extra_field(delta, "reasoning")
                    if reasoning_piece:
                        if not reasoning_started:
                            reasoning_piece = reasoning_piece.lstrip("\n")
                            reasoning_started = bool(reasoning_piece)
                        if reasoning_piece:
                            yield {"type": "reasoning_delta", "text": reasoning_piece}

                    if delta.content:
                        text = delta.content
                        if not content_started:
                            text = text.lstrip("\n")
                            content_started = bool(text)
                        if text:
                            content_parts.append(text)
                            yield {"type": "answer_delta", "text": text}

                    for tc in delta.tool_calls or []:
                        entry = tool_calls_acc.setdefault(
                            tc.index, {"id": None, "name": None, "arguments": ""}
                        )
                        if tc.id:
                            entry["id"] = tc.id
                        if tc.function and tc.function.name:
                            entry["name"] = tc.function.name
                        if tc.function and tc.function.arguments:
                            entry["arguments"] += tc.function.arguments
            except Exception as e:
                yield {"type": "error", "content": f"LLM stream error: {e}"}
                return

            content = "".join(content_parts)

            if not tool_calls_acc:
                self._history.append({"role": "assistant", "content": content})
                self.compact_history()
                return

            self._history.append(
                {
                    "role": "assistant",
                    "content": content or None,
                    "tool_calls": [
                        {
                            "id": e["id"],
                            "type": "function",
                            "function": {"name": e["name"], "arguments": e["arguments"]},
                        }
                        for e in tool_calls_acc.values()
                    ],
                }
            )

            for e in tool_calls_acc.values():
                tool = REGISTRY.get(e["name"])
                try:
                    args = json.loads(e["arguments"]) if e["arguments"] else {}
                except json.JSONDecodeError as err:
                    args = {}
                    result = f"Error: Malformed JSON arguments: {err}"
                else:
                    if tool:
                        perm = self._permission_gate.check(e["name"], args)
                        if not perm.allowed:
                            result = f"Action rejected: {perm.reason}"
                        else:
                            try:
                                result = tool.handler(**args)
                            except Exception as err:
                                result = f"Error executing tool '{e['name']}': {err}"
                    else:
                        result = f"Unknown tool: {e['name']}"

                yield {"type": "tool_call", "name": e["name"], "args": args, "result": result}

                # Cap size of tool result stored in history to prevent context window explosion
                hist_content = str(result)
                if len(hist_content) > 20_000:
                    hist_content = (
                        hist_content[:10_000]
                        + f"\n... [Context truncated {len(hist_content) - 20000} chars] ...\n"
                        + hist_content[-10_000:]
                    )

                self._history.append(
                    {"role": "tool", "tool_call_id": e["id"], "content": hist_content}
                )

        yield {"type": "error", "content": "Reached maximum turns without final response."}
        self.compact_history()
